#ifndef RANDOM_H
#define RANDOM_H

#include <common_types.h>

void random_init( uint32 seed );
uint32 random_get( void );

#endif
