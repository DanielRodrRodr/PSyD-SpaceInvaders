ALBERTO DELGADO Y DANIEL RODRIGUEZ
1. En el video puede que no se aprecien los laseres del jugador y del enemigo, se ve mejor en persona. 
2. No hay audio porque no conseguimos importar los .wavs a la placa. Y hemos tenido que comentar las funciones de sound.c para evitar escuchar ruido blanco. 