#include <iis.h>
#include "sound.h"

void sound_play(Sound *self) {
	iis_playWawFile(self->wav, 0);
}

void sound_loop(Sound *self) {
	iis_playWawFile(self->wav, 1);
}

void sound_stop(void) {
	iis_pause();
}

boolean sound_isPlaying(void) {
	return (boolean) iis_status();
}
